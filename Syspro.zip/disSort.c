void countingsort(int n,int *a)
{
        int i,j,k;
      int max = a[0]; 
    
    for (i = 1; i < n; i++) 
        if (a[i] > max) 
            max = a[i]; 

     int *count = (int*)malloc(sizeof(int)*max);
     
     for(i=0;i<n;++i)
      count[a[i]]=count[a[i]]+1;
      
     k = 0;
     for(i=0;i<=max;++i)
      for(j=1;j<=count[i];++j){
         a[k]=i;
         k++;
      }
      return ;
       
}